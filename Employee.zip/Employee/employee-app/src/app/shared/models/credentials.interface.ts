export interface Credentials{
    userName: string;
    password: string;
}