export interface EmployeeType{
    employeeTypeId: number;
    employeeTypeName: string;
}