export interface EmployeeGrid{
    employeeId: number;
    name: string;
    designation: string;
    managerName: string;
    employeeType: string;
}